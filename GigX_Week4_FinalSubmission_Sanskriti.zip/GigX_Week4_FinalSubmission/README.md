# GigX Platform - Week 4: Final Submission

## 📌 Features Implemented
- Provider Dashboard: View all posted gigs.
- Seeker Dashboard: Favorite gigs, optionally apply.
- Role-based view rendering.
- ManyToManyField for favorite gigs.
- Secure .env handling for sensitive configs.

## 🛠 Tech Stack
- Django 4+
- SQLite3 (default)
- Postman for API Testing
- Python-Decouple (optional)

## ⚙ Setup Instructions
1. Clone the repo or unzip the project folder.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create `.env` file in root:
   ```
   SECRET_KEY=your_secret_key
   DEBUG=True
   ```
4. Run migrations and server:
   ```bash
   python manage.py migrate
   python manage.py runserver
   ```

## 🖼 Screenshots
- 📍 Home Page
- 👤 Provider Dashboard
- ❤️ Seeker Favorites

## 🔒 Note
- `.env` is excluded from GitHub using `.gitignore`.

--- 
Happy Coding! 🎉
